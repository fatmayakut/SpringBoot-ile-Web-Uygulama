package com.fyakut.webapps.inventory.service;

import java.util.List;

import com.fyakut.webapps.inventory.domain.Item;
import com.fyakut.webapps.inventory.domain.ItemAddForm;
import com.fyakut.webapps.inventory.domain.User;

/**
 * Created by fyakut
 */

public interface ItemService {
    Item getItemById(long id);

    void addItem(ItemAddForm form);

    Iterable<Item> getItems();

    Item assignItem(String username, long itemId);

    void deleteItemById(long id);
}
