package com.fyakut.webapps.inventory.repository;

import org.springframework.data.repository.CrudRepository;

import com.fyakut.webapps.inventory.domain.User;

/**
 * Created by fyakut
 */

public interface UserRepository extends CrudRepository<User, Long> {
    User findByUsername(String username);
}
