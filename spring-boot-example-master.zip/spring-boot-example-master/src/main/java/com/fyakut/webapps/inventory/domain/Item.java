package com.fyakut.webapps.inventory.domain;

import javax.persistence.*;

/**
 * Created by fyakut
 */

@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)//tabloya uygun primarykey verir
    @Column(name = "id", nullable = false, updatable = false)
    private long id;

    @Column(name = "code", nullable = false, updatable = false, unique = true)//guncellenebilir ilk olarak null ve uniq değer 
    private String inventoryCode;
    
    @Column(name = "type", nullable = false)
    private String type;

    @ManyToOne(fetch = FetchType.LAZY) //relationship join işlemi
    @JoinColumn(name = "user_id")
    private User user;

    public Item() {

    }

    public Item(String inventoryCode, String type) {
        this.inventoryCode = inventoryCode;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public String getInventoryCode() {
        return inventoryCode;
    }

    public void setInventoryCode(String inventoryCode) {
        this.inventoryCode = inventoryCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

	@Override
	public String toString() {
		return "Item [id=" + id + ", inventoryCode=" + inventoryCode + ", type=" + type + ", user=" + user + "]";
	}
}
