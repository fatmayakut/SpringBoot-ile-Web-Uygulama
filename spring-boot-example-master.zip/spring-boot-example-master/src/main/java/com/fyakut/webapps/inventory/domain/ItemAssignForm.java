package com.fyakut.webapps.inventory.domain;

/**
 * Created by fyakut
 */
public class ItemAssignForm {
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
