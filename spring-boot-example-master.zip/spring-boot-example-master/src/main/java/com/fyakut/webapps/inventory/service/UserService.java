package com.fyakut.webapps.inventory.service;

import java.util.List;
import java.util.Map;

import com.fyakut.webapps.inventory.domain.Item;
import com.fyakut.webapps.inventory.domain.User;

/**
 * Created by fyakut
 */

public interface UserService {
    User getUserById(long id);

    User getUserByUsername(String username);

    User addUser(User user);

    Iterable<User> getUsers();

    Map<String, List<Item>> numberOfItemsByType(long userId);

    List<String> getUsernames();
}
