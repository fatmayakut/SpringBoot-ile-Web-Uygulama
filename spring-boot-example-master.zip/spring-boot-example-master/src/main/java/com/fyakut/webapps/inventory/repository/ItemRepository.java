package com.fyakut.webapps.inventory.repository;

import org.springframework.data.repository.CrudRepository;

import com.fyakut.webapps.inventory.domain.Item;

/**
 * Created by fyakut
 */


public interface ItemRepository extends CrudRepository<Item, Long> {
    Item findByInventoryCode(String inventoryCode);
}
